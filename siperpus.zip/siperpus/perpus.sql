-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 10 Nov 2024 pada 15.28
-- Versi server: 10.4.32-MariaDB
-- Versi PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `perpus`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `anggota`
--

CREATE TABLE `anggota` (
  `kode_anggota` int(11) NOT NULL,
  `nama_anggota` varchar(35) NOT NULL,
  `tgl_masuk` date NOT NULL,
  `alamat` text NOT NULL,
  `telepon` varchar(15) NOT NULL,
  `keterangan` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `anggota`
--

INSERT INTO `anggota` (`kode_anggota`, `nama_anggota`, `tgl_masuk`, `alamat`, `telepon`, `keterangan`) VALUES
(1, 'Aa Yudha Nugraha', '2013-01-16', 'Jl.Bumi Raya,RT01 RW02-Ciomas', '085759965394', 'Kelas XI RPL 1'),
(2, 'Ade Indra', '2013-01-17', 'Jl.Bumi Putra,RT02RW04-Sukasari', '085315721521', 'Kelas XII RPL 3'),
(3, 'Ade Maelani', '2013-01-18', 'Jl.Bumi Graha,RT02RW02-Banjaran', '087122676786', 'Kelas XI RPL 2'),
(4, 'Agus Nugraha', '2013-01-19', 'Jl.Bumi Jaya,RT01RW01-Basuki', '085797339927', 'Kelas XI RPL 1'),
(5, 'Alis Trikandari', '2013-01-20', 'Jl.Bukit Bungur,Blok Selasa', '081234567887', 'Kelas XII RPL 4'),
(6, 'Aldyana', '2013-01-21', 'Jl.Mekarrahayu,RT01RW01-Langgeng', '085224196197', 'Kelas XII RPL 3'),
(7, 'Alinka Dwiyana Putri', '2013-01-22', 'Jl.Prabu Raya,RT04RW02-Sindangkerta', '081234777889', 'Kelas XI RPL 2'),
(8, 'Arif Syamsul', '2013-01-23', 'Jl.Prabu Putra,RT01RW02-Calingcing', '0812345678901', 'Kelas XII RPL 4'),
(9, 'Bangkit Munggaran', '2012-03-02', 'Jl.Prabu Graha,RT1RW02-Malongpong', '085322103277', 'Kelas XI RPL 3');

-- --------------------------------------------------------

--
-- Struktur dari tabel `buku`
--

CREATE TABLE `buku` (
  `kode_buku` int(11) NOT NULL,
  `tgl_entri` date NOT NULL,
  `ISBN` varchar(50) NOT NULL,
  `kode_jenis` int(11) NOT NULL,
  `judul` varchar(100) NOT NULL,
  `kode_penulis` int(11) NOT NULL,
  `kode_penerbit` int(11) NOT NULL,
  `tahun_terbit` year(4) NOT NULL,
  `jumlah_buku` int(11) NOT NULL,
  `nomor_rak` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `buku`
--

INSERT INTO `buku` (`kode_buku`, `tgl_entri`, `ISBN`, `kode_jenis`, `judul`, `kode_penulis`, `kode_penerbit`, `tahun_terbit`, `jumlah_buku`, `nomor_rak`) VALUES
(10, '2013-01-18', '111-222-333-444-3 	', 5, 'Desain Rumah Idaman Menggunakan Auto CAD', 8, 4, '1998', 10, 3),
(9, '2013-01-18', '111-222-333-444-2', 9, 'Web Canggih dengan PHP dan MySql', 13, 2010, '2006', 10, 2),
(8, '2013-01-17', ' 	111-222-333-444-1', 10, 'Trik-trik MS Office 2010', 9, 5, '2009', 10, 1),
(11, '2013-01-19', '111-222-333-444-4', 7, 'Cara Cepat Mendownload File', 10, 3, '2006', 10, 4),
(12, '2013-01-20', '111-222-333-444-5', 9, 'Membuat Aplikasi Windows Phone', 12, 6, '2002', 10, 5),
(13, '2013-01-04', '111-222-333-444-6', 15, 'Pengolahan Ubi Merah', 14, 5, '2000', 2, 15);

-- --------------------------------------------------------

--
-- Struktur dari tabel `login`
--

CREATE TABLE `login` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `login`
--

INSERT INTO `login` (`id`, `username`, `password`) VALUES
(1, 'Admin', 'slebew123');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `anggota`
--
ALTER TABLE `anggota`
  ADD PRIMARY KEY (`kode_anggota`);

--
-- Indeks untuk tabel `buku`
--
ALTER TABLE `buku`
  ADD PRIMARY KEY (`kode_buku`);

--
-- Indeks untuk tabel `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `anggota`
--
ALTER TABLE `anggota`
  MODIFY `kode_anggota` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT untuk tabel `buku`
--
ALTER TABLE `buku`
  MODIFY `kode_buku` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT untuk tabel `login`
--
ALTER TABLE `login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
