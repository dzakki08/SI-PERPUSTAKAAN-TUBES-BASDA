<?php
// Menghubungkan ke database
require 'C:\xampp\htdocs\siperpus\koneksi.php';  // Pastikan file koneksi ada dan terhubung
session_start();  // Memulai sesi

// Memeriksa apakah form dikirim dengan metode POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Mengambil data username dan password dari form
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Mempersiapkan SQL untuk mengambil hash password berdasarkan username
    $stmt = $conn->prepare("SELECT id, password FROM login WHERE username = ?");
    $stmt->bind_param("s", $username); // Mengikat parameter
    $stmt->execute();
    $stmt->store_result();

    // Memeriksa apakah username ada di database
    if ($stmt->num_rows > 0) {
        // Mengambil hasilnya (ID dan hashed_password)
        $stmt->bind_result($id, $hashed_password);
        $stmt->fetch();

        // Verifikasi password input dengan hash password dari database
        if (password_verify($password, $hashed_password)) {
            // Jika password benar, simpan informasi sesi pengguna
            $_SESSION["loggedin"] = true;
            $_SESSION["id"] = $id;
            $_SESSION["username"] = $username;

            // Redirect ke halaman admin atau dashboard
            header("location: Admin/index.php");
            exit;
        } else {
            echo "<script>alert('Password salah!'); window.location.href = 'index.html';</script>";
        }
    } else {
        echo "<script>alert('Username tidak ditemukan!'); window.location.href = 'index.html';</script>";
    }

    // Menutup pernyataan
    $stmt->close();
}

// Menutup koneksi database
$conn->close();
?>
