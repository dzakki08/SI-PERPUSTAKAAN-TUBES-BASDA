<?php
include 'C:\xampp\htdocs\siperpus\koneksi.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];
    
    // Mengenkripsi password sebelum menyimpannya
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // Simpan username dan hashed_password ke database
    $stmt = $conn->prepare("INSERT INTO login (username, password) VALUES (?, ?)");
    $stmt->bind_param("ss", $username, $hashed_password);

    if ($stmt->execute()) {
        echo "<script>alert('user berhasil didaftarkan'); window.location.href = 'index.html';</script>";
    } else {
        echo "<script>alert('Terjadi Kesalahan'); window.location.href = 'index.html';</script>";
    }

    $stmt->close();
    $conn->close();
}
?>
