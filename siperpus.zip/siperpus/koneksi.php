<?php
// Database configuration
$servername = "localhost";
$dbname = "perpus";
$dbusername = "root";
$dbpassword = "";

// Connect to the database
$conn = new mysqli($servername, $dbusername, $dbpassword, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

?>